##### Dimensions ######
WIDHT = 1300
HEIGHT = 800

# Positions

ground_pos = 607

#### Colors #####

# background_image
background = (238, 167, 87)
ground_color = (34, 20, 37)
mountains_color = (217, 99, 38)
mountains_back_color = (232, 164, 89)
sun_color = (241, 244, 180)
sun_color2 = (234, 207, 131)
sun_color3 = (235, 194, 114)

# soldier Clothes
eth = (80, 51, 53)
ity = (236, 188, 180)

# soldier Skins
eth_skin = [(161, 102, 94), (80, 51, 53), (89, 47, 42)]
ita_skin = [(197, 140, 133), (236, 188, 180), (209, 163, 164)]

# weapon
akwod = (99, 57, 21)
